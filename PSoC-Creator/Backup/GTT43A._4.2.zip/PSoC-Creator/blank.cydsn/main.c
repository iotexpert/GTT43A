#include "project.h"
#include <stdio.h>
char buff[128];

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    while(1);
}
