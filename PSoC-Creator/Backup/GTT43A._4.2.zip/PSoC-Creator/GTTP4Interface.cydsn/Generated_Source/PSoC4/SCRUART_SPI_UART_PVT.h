/***************************************************************************//**
* \file SCRUART_SPI_UART_PVT.h
* \version 4.0
*
* \brief
*  This private file provides constants and parameter values for the
*  SCB Component in SPI and UART modes.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_PVT_SCRUART_H)
#define CY_SCB_SPI_UART_PVT_SCRUART_H

#include "SCRUART_SPI_UART.h"


/***************************************
*     Internal Global Vars
***************************************/

#if (SCRUART_INTERNAL_RX_SW_BUFFER_CONST)
    extern volatile uint32  SCRUART_rxBufferHead;
    extern volatile uint32  SCRUART_rxBufferTail;
    
    /**
    * \addtogroup group_globals
    * @{
    */
    
    /** Sets when internal software receive buffer overflow
     *  was occurred.
    */  
    extern volatile uint8   SCRUART_rxBufferOverflow;
    /** @} globals */
#endif /* (SCRUART_INTERNAL_RX_SW_BUFFER_CONST) */

#if (SCRUART_INTERNAL_TX_SW_BUFFER_CONST)
    extern volatile uint32  SCRUART_txBufferHead;
    extern volatile uint32  SCRUART_txBufferTail;
#endif /* (SCRUART_INTERNAL_TX_SW_BUFFER_CONST) */

#if (SCRUART_INTERNAL_RX_SW_BUFFER)
    extern volatile uint8 SCRUART_rxBufferInternal[SCRUART_INTERNAL_RX_BUFFER_SIZE];
#endif /* (SCRUART_INTERNAL_RX_SW_BUFFER) */

#if (SCRUART_INTERNAL_TX_SW_BUFFER)
    extern volatile uint8 SCRUART_txBufferInternal[SCRUART_TX_BUFFER_SIZE];
#endif /* (SCRUART_INTERNAL_TX_SW_BUFFER) */


/***************************************
*     Private Function Prototypes
***************************************/

void SCRUART_SpiPostEnable(void);
void SCRUART_SpiStop(void);

#if (SCRUART_SCB_MODE_SPI_CONST_CFG)
    void SCRUART_SpiInit(void);
#endif /* (SCRUART_SCB_MODE_SPI_CONST_CFG) */

#if (SCRUART_SPI_WAKE_ENABLE_CONST)
    void SCRUART_SpiSaveConfig(void);
    void SCRUART_SpiRestoreConfig(void);
#endif /* (SCRUART_SPI_WAKE_ENABLE_CONST) */

void SCRUART_UartPostEnable(void);
void SCRUART_UartStop(void);

#if (SCRUART_SCB_MODE_UART_CONST_CFG)
    void SCRUART_UartInit(void);
#endif /* (SCRUART_SCB_MODE_UART_CONST_CFG) */

#if (SCRUART_UART_WAKE_ENABLE_CONST)
    void SCRUART_UartSaveConfig(void);
    void SCRUART_UartRestoreConfig(void);
#endif /* (SCRUART_UART_WAKE_ENABLE_CONST) */


/***************************************
*         UART API Constants
***************************************/

/* UART RX and TX position to be used in SCRUART_SetPins() */
#define SCRUART_UART_RX_PIN_ENABLE    (SCRUART_UART_RX)
#define SCRUART_UART_TX_PIN_ENABLE    (SCRUART_UART_TX)

/* UART RTS and CTS position to be used in  SCRUART_SetPins() */
#define SCRUART_UART_RTS_PIN_ENABLE    (0x10u)
#define SCRUART_UART_CTS_PIN_ENABLE    (0x20u)


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Interrupt processing */
#define SCRUART_SpiUartEnableIntRx(intSourceMask)  SCRUART_SetRxInterruptMode(intSourceMask)
#define SCRUART_SpiUartEnableIntTx(intSourceMask)  SCRUART_SetTxInterruptMode(intSourceMask)
uint32  SCRUART_SpiUartDisableIntRx(void);
uint32  SCRUART_SpiUartDisableIntTx(void);


#endif /* (CY_SCB_SPI_UART_PVT_SCRUART_H) */


/* [] END OF FILE */
