/***************************************************************************//**
* \file SCRUART_PM.c
* \version 4.0
*
* \brief
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SCRUART.h"
#include "SCRUART_PVT.h"

#if(SCRUART_SCB_MODE_I2C_INC)
    #include "SCRUART_I2C_PVT.h"
#endif /* (SCRUART_SCB_MODE_I2C_INC) */

#if(SCRUART_SCB_MODE_EZI2C_INC)
    #include "SCRUART_EZI2C_PVT.h"
#endif /* (SCRUART_SCB_MODE_EZI2C_INC) */

#if(SCRUART_SCB_MODE_SPI_INC || SCRUART_SCB_MODE_UART_INC)
    #include "SCRUART_SPI_UART_PVT.h"
#endif /* (SCRUART_SCB_MODE_SPI_INC || SCRUART_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

#if(SCRUART_SCB_MODE_UNCONFIG_CONST_CFG || \
   (SCRUART_SCB_MODE_I2C_CONST_CFG   && (!SCRUART_I2C_WAKE_ENABLE_CONST))   || \
   (SCRUART_SCB_MODE_EZI2C_CONST_CFG && (!SCRUART_EZI2C_WAKE_ENABLE_CONST)) || \
   (SCRUART_SCB_MODE_SPI_CONST_CFG   && (!SCRUART_SPI_WAKE_ENABLE_CONST))   || \
   (SCRUART_SCB_MODE_UART_CONST_CFG  && (!SCRUART_UART_WAKE_ENABLE_CONST)))

    SCRUART_BACKUP_STRUCT SCRUART_backup =
    {
        0u, /* enableState */
    };
#endif


/*******************************************************************************
* Function Name: SCRUART_Sleep
****************************************************************************//**
*
*  Prepares the SCRUART component to enter Deep Sleep.
*  The “Enable wakeup from Deep Sleep Mode” selection has an influence on this 
*  function implementation:
*  - Checked: configures the component to be wakeup source from Deep Sleep.
*  - Unchecked: stores the current component state (enabled or disabled) and 
*    disables the component. See SCB_Stop() function for details about component 
*    disabling.
*
*  Call the SCRUART_Sleep() function before calling the 
*  CyPmSysDeepSleep() function. 
*  Refer to the PSoC Creator System Reference Guide for more information about 
*  power management functions and Low power section of this document for the 
*  selected mode.
*
*  This function should not be called before entering Sleep.
*
*******************************************************************************/
void SCRUART_Sleep(void)
{
#if(SCRUART_SCB_MODE_UNCONFIG_CONST_CFG)

    if(SCRUART_SCB_WAKE_ENABLE_CHECK)
    {
        if(SCRUART_SCB_MODE_I2C_RUNTM_CFG)
        {
            SCRUART_I2CSaveConfig();
        }
        else if(SCRUART_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            SCRUART_EzI2CSaveConfig();
        }
    #if(!SCRUART_CY_SCBIP_V1)
        else if(SCRUART_SCB_MODE_SPI_RUNTM_CFG)
        {
            SCRUART_SpiSaveConfig();
        }
        else if(SCRUART_SCB_MODE_UART_RUNTM_CFG)
        {
            SCRUART_UartSaveConfig();
        }
    #endif /* (!SCRUART_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        SCRUART_backup.enableState = (uint8) SCRUART_GET_CTRL_ENABLED;

        if(0u != SCRUART_backup.enableState)
        {
            SCRUART_Stop();
        }
    }

#else

    #if (SCRUART_SCB_MODE_I2C_CONST_CFG && SCRUART_I2C_WAKE_ENABLE_CONST)
        SCRUART_I2CSaveConfig();

    #elif (SCRUART_SCB_MODE_EZI2C_CONST_CFG && SCRUART_EZI2C_WAKE_ENABLE_CONST)
        SCRUART_EzI2CSaveConfig();

    #elif (SCRUART_SCB_MODE_SPI_CONST_CFG && SCRUART_SPI_WAKE_ENABLE_CONST)
        SCRUART_SpiSaveConfig();

    #elif (SCRUART_SCB_MODE_UART_CONST_CFG && SCRUART_UART_WAKE_ENABLE_CONST)
        SCRUART_UartSaveConfig();

    #else

        SCRUART_backup.enableState = (uint8) SCRUART_GET_CTRL_ENABLED;

        if(0u != SCRUART_backup.enableState)
        {
            SCRUART_Stop();
        }

    #endif /* defined (SCRUART_SCB_MODE_I2C_CONST_CFG) && (SCRUART_I2C_WAKE_ENABLE_CONST) */

#endif /* (SCRUART_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SCRUART_Wakeup
****************************************************************************//**
*
*  Prepares the SCRUART component for Active mode operation after 
*  Deep Sleep.
*  The “Enable wakeup from Deep Sleep Mode” selection has influence on this 
*  function implementation:
*  - Checked: restores the component Active mode configuration.
*  - Unchecked: enables the component if it was enabled before enter Deep Sleep.
*
*  This function should not be called after exiting Sleep.
*
*  \sideeffect
*   Calling the SCRUART_Wakeup() function without first calling the 
*   SCRUART_Sleep() function may produce unexpected behavior.
*
*******************************************************************************/
void SCRUART_Wakeup(void)
{
#if(SCRUART_SCB_MODE_UNCONFIG_CONST_CFG)

    if(SCRUART_SCB_WAKE_ENABLE_CHECK)
    {
        if(SCRUART_SCB_MODE_I2C_RUNTM_CFG)
        {
            SCRUART_I2CRestoreConfig();
        }
        else if(SCRUART_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            SCRUART_EzI2CRestoreConfig();
        }
    #if(!SCRUART_CY_SCBIP_V1)
        else if(SCRUART_SCB_MODE_SPI_RUNTM_CFG)
        {
            SCRUART_SpiRestoreConfig();
        }
        else if(SCRUART_SCB_MODE_UART_RUNTM_CFG)
        {
            SCRUART_UartRestoreConfig();
        }
    #endif /* (!SCRUART_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        if(0u != SCRUART_backup.enableState)
        {
            SCRUART_Enable();
        }
    }

#else

    #if (SCRUART_SCB_MODE_I2C_CONST_CFG  && SCRUART_I2C_WAKE_ENABLE_CONST)
        SCRUART_I2CRestoreConfig();

    #elif (SCRUART_SCB_MODE_EZI2C_CONST_CFG && SCRUART_EZI2C_WAKE_ENABLE_CONST)
        SCRUART_EzI2CRestoreConfig();

    #elif (SCRUART_SCB_MODE_SPI_CONST_CFG && SCRUART_SPI_WAKE_ENABLE_CONST)
        SCRUART_SpiRestoreConfig();

    #elif (SCRUART_SCB_MODE_UART_CONST_CFG && SCRUART_UART_WAKE_ENABLE_CONST)
        SCRUART_UartRestoreConfig();

    #else

        if(0u != SCRUART_backup.enableState)
        {
            SCRUART_Enable();
        }

    #endif /* (SCRUART_I2C_WAKE_ENABLE_CONST) */

#endif /* (SCRUART_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/* [] END OF FILE */
