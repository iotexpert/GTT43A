/***************************************************************************//**
* \file .h
* \version 4.0
*
* \brief
*  This private file provides constants and parameter values for the
*  SCB Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_SCRUART_H)
#define CY_SCB_PVT_SCRUART_H

#include "SCRUART.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define SCRUART_SetI2CExtClkInterruptMode(interruptMask) SCRUART_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define SCRUART_ClearI2CExtClkInterruptSource(interruptMask) SCRUART_CLEAR_INTR_I2C_EC(interruptMask)
#define SCRUART_GetI2CExtClkInterruptSource()                (SCRUART_INTR_I2C_EC_REG)
#define SCRUART_GetI2CExtClkInterruptMode()                  (SCRUART_INTR_I2C_EC_MASK_REG)
#define SCRUART_GetI2CExtClkInterruptSourceMasked()          (SCRUART_INTR_I2C_EC_MASKED_REG)

#if (!SCRUART_CY_SCBIP_V1)
    /* APIs to service INTR_SPI_EC register */
    #define SCRUART_SetSpiExtClkInterruptMode(interruptMask) \
                                                                SCRUART_WRITE_INTR_SPI_EC_MASK(interruptMask)
    #define SCRUART_ClearSpiExtClkInterruptSource(interruptMask) \
                                                                SCRUART_CLEAR_INTR_SPI_EC(interruptMask)
    #define SCRUART_GetExtSpiClkInterruptSource()                 (SCRUART_INTR_SPI_EC_REG)
    #define SCRUART_GetExtSpiClkInterruptMode()                   (SCRUART_INTR_SPI_EC_MASK_REG)
    #define SCRUART_GetExtSpiClkInterruptSourceMasked()           (SCRUART_INTR_SPI_EC_MASKED_REG)
#endif /* (!SCRUART_CY_SCBIP_V1) */

#if(SCRUART_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void SCRUART_SetPins(uint32 mode, uint32 subMode, uint32 uartEnableMask);
#endif /* (SCRUART_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Vars with External Linkage
***************************************/

#if (SCRUART_SCB_IRQ_INTERNAL)
#if !defined (CY_REMOVE_SCRUART_CUSTOM_INTR_HANDLER)
    extern cyisraddress SCRUART_customIntrHandler;
#endif /* !defined (CY_REMOVE_SCRUART_CUSTOM_INTR_HANDLER) */
#endif /* (SCRUART_SCB_IRQ_INTERNAL) */

extern SCRUART_BACKUP_STRUCT SCRUART_backup;

#if(SCRUART_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common configuration variables */
    extern uint8 SCRUART_scbMode;
    extern uint8 SCRUART_scbEnableWake;
    extern uint8 SCRUART_scbEnableIntr;

    /* I2C configuration variables */
    extern uint8 SCRUART_mode;
    extern uint8 SCRUART_acceptAddr;

    /* SPI/UART configuration variables */
    extern volatile uint8 * SCRUART_rxBuffer;
    extern uint8   SCRUART_rxDataBits;
    extern uint32  SCRUART_rxBufferSize;

    extern volatile uint8 * SCRUART_txBuffer;
    extern uint8   SCRUART_txDataBits;
    extern uint32  SCRUART_txBufferSize;

    /* EZI2C configuration variables */
    extern uint8 SCRUART_numberOfAddr;
    extern uint8 SCRUART_subAddrSize;
#endif /* (SCRUART_SCB_MODE_UNCONFIG_CONST_CFG) */

#if (! (SCRUART_SCB_MODE_I2C_CONST_CFG || \
        SCRUART_SCB_MODE_EZI2C_CONST_CFG))
    extern uint16 SCRUART_IntrTxMask;
#endif /* (! (SCRUART_SCB_MODE_I2C_CONST_CFG || \
              SCRUART_SCB_MODE_EZI2C_CONST_CFG)) */


/***************************************
*        Conditional Macro
****************************************/

#if(SCRUART_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Defines run time operation mode */
    #define SCRUART_SCB_MODE_I2C_RUNTM_CFG     (SCRUART_SCB_MODE_I2C      == SCRUART_scbMode)
    #define SCRUART_SCB_MODE_SPI_RUNTM_CFG     (SCRUART_SCB_MODE_SPI      == SCRUART_scbMode)
    #define SCRUART_SCB_MODE_UART_RUNTM_CFG    (SCRUART_SCB_MODE_UART     == SCRUART_scbMode)
    #define SCRUART_SCB_MODE_EZI2C_RUNTM_CFG   (SCRUART_SCB_MODE_EZI2C    == SCRUART_scbMode)
    #define SCRUART_SCB_MODE_UNCONFIG_RUNTM_CFG \
                                                        (SCRUART_SCB_MODE_UNCONFIG == SCRUART_scbMode)

    /* Defines wakeup enable */
    #define SCRUART_SCB_WAKE_ENABLE_CHECK       (0u != SCRUART_scbEnableWake)
#endif /* (SCRUART_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Defines maximum number of SCB pins */
#if (!SCRUART_CY_SCBIP_V1)
    #define SCRUART_SCB_PINS_NUMBER    (7u)
#else
    #define SCRUART_SCB_PINS_NUMBER    (2u)
#endif /* (!SCRUART_CY_SCBIP_V1) */

#endif /* (CY_SCB_PVT_SCRUART_H) */


/* [] END OF FILE */
