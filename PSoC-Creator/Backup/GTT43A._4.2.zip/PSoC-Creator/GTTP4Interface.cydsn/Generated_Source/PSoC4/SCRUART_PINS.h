/***************************************************************************//**
* \file SCRUART_PINS.h
* \version 4.0
*
* \brief
*  This file provides constants and parameter values for the pin components
*  buried into SCB Component.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PINS_SCRUART_H)
#define CY_SCB_PINS_SCRUART_H

#include "cydevice_trm.h"
#include "cyfitter.h"
#include "cytypes.h"


/***************************************
*   Conditional Compilation Parameters
****************************************/

/* Unconfigured pins */
#define SCRUART_REMOVE_RX_WAKE_SCL_MOSI_PIN  (1u)
#define SCRUART_REMOVE_RX_SCL_MOSI_PIN      (1u)
#define SCRUART_REMOVE_TX_SDA_MISO_PIN      (1u)
#define SCRUART_REMOVE_CTS_SCLK_PIN      (1u)
#define SCRUART_REMOVE_RTS_SS0_PIN      (1u)
#define SCRUART_REMOVE_SS1_PIN                 (1u)
#define SCRUART_REMOVE_SS2_PIN                 (1u)
#define SCRUART_REMOVE_SS3_PIN                 (1u)

/* Mode defined pins */
#define SCRUART_REMOVE_I2C_PINS                (1u)
#define SCRUART_REMOVE_SPI_MASTER_PINS         (1u)
#define SCRUART_REMOVE_SPI_MASTER_SCLK_PIN     (1u)
#define SCRUART_REMOVE_SPI_MASTER_MOSI_PIN     (1u)
#define SCRUART_REMOVE_SPI_MASTER_MISO_PIN     (1u)
#define SCRUART_REMOVE_SPI_MASTER_SS0_PIN      (1u)
#define SCRUART_REMOVE_SPI_MASTER_SS1_PIN      (1u)
#define SCRUART_REMOVE_SPI_MASTER_SS2_PIN      (1u)
#define SCRUART_REMOVE_SPI_MASTER_SS3_PIN      (1u)
#define SCRUART_REMOVE_SPI_SLAVE_PINS          (1u)
#define SCRUART_REMOVE_SPI_SLAVE_MOSI_PIN      (1u)
#define SCRUART_REMOVE_SPI_SLAVE_MISO_PIN      (1u)
#define SCRUART_REMOVE_UART_TX_PIN             (0u)
#define SCRUART_REMOVE_UART_RX_TX_PIN          (1u)
#define SCRUART_REMOVE_UART_RX_PIN             (0u)
#define SCRUART_REMOVE_UART_RX_WAKE_PIN        (1u)
#define SCRUART_REMOVE_UART_RTS_PIN            (1u)
#define SCRUART_REMOVE_UART_CTS_PIN            (1u)

/* Unconfigured pins */
#define SCRUART_RX_WAKE_SCL_MOSI_PIN (0u == SCRUART_REMOVE_RX_WAKE_SCL_MOSI_PIN)
#define SCRUART_RX_SCL_MOSI_PIN     (0u == SCRUART_REMOVE_RX_SCL_MOSI_PIN)
#define SCRUART_TX_SDA_MISO_PIN     (0u == SCRUART_REMOVE_TX_SDA_MISO_PIN)
#define SCRUART_CTS_SCLK_PIN     (0u == SCRUART_REMOVE_CTS_SCLK_PIN)
#define SCRUART_RTS_SS0_PIN     (0u == SCRUART_REMOVE_RTS_SS0_PIN)
#define SCRUART_SS1_PIN                (0u == SCRUART_REMOVE_SS1_PIN)
#define SCRUART_SS2_PIN                (0u == SCRUART_REMOVE_SS2_PIN)
#define SCRUART_SS3_PIN                (0u == SCRUART_REMOVE_SS3_PIN)

/* Mode defined pins */
#define SCRUART_I2C_PINS               (0u == SCRUART_REMOVE_I2C_PINS)
#define SCRUART_SPI_MASTER_PINS        (0u == SCRUART_REMOVE_SPI_MASTER_PINS)
#define SCRUART_SPI_MASTER_SCLK_PIN    (0u == SCRUART_REMOVE_SPI_MASTER_SCLK_PIN)
#define SCRUART_SPI_MASTER_MOSI_PIN    (0u == SCRUART_REMOVE_SPI_MASTER_MOSI_PIN)
#define SCRUART_SPI_MASTER_MISO_PIN    (0u == SCRUART_REMOVE_SPI_MASTER_MISO_PIN)
#define SCRUART_SPI_MASTER_SS0_PIN     (0u == SCRUART_REMOVE_SPI_MASTER_SS0_PIN)
#define SCRUART_SPI_MASTER_SS1_PIN     (0u == SCRUART_REMOVE_SPI_MASTER_SS1_PIN)
#define SCRUART_SPI_MASTER_SS2_PIN     (0u == SCRUART_REMOVE_SPI_MASTER_SS2_PIN)
#define SCRUART_SPI_MASTER_SS3_PIN     (0u == SCRUART_REMOVE_SPI_MASTER_SS3_PIN)
#define SCRUART_SPI_SLAVE_PINS         (0u == SCRUART_REMOVE_SPI_SLAVE_PINS)
#define SCRUART_SPI_SLAVE_MOSI_PIN     (0u == SCRUART_REMOVE_SPI_SLAVE_MOSI_PIN)
#define SCRUART_SPI_SLAVE_MISO_PIN     (0u == SCRUART_REMOVE_SPI_SLAVE_MISO_PIN)
#define SCRUART_UART_TX_PIN            (0u == SCRUART_REMOVE_UART_TX_PIN)
#define SCRUART_UART_RX_TX_PIN         (0u == SCRUART_REMOVE_UART_RX_TX_PIN)
#define SCRUART_UART_RX_PIN            (0u == SCRUART_REMOVE_UART_RX_PIN)
#define SCRUART_UART_RX_WAKE_PIN       (0u == SCRUART_REMOVE_UART_RX_WAKE_PIN)
#define SCRUART_UART_RTS_PIN           (0u == SCRUART_REMOVE_UART_RTS_PIN)
#define SCRUART_UART_CTS_PIN           (0u == SCRUART_REMOVE_UART_CTS_PIN)


/***************************************
*             Includes
****************************************/

#if (SCRUART_RX_WAKE_SCL_MOSI_PIN)
    #include "SCRUART_uart_rx_wake_i2c_scl_spi_mosi.h"
#endif /* (SCRUART_RX_SCL_MOSI) */

#if (SCRUART_RX_SCL_MOSI_PIN)
    #include "SCRUART_uart_rx_i2c_scl_spi_mosi.h"
#endif /* (SCRUART_RX_SCL_MOSI) */

#if (SCRUART_TX_SDA_MISO_PIN)
    #include "SCRUART_uart_tx_i2c_sda_spi_miso.h"
#endif /* (SCRUART_TX_SDA_MISO) */

#if (SCRUART_CTS_SCLK_PIN)
    #include "SCRUART_uart_cts_spi_sclk.h"
#endif /* (SCRUART_CTS_SCLK) */

#if (SCRUART_RTS_SS0_PIN)
    #include "SCRUART_uart_rts_spi_ss0.h"
#endif /* (SCRUART_RTS_SS0_PIN) */

#if (SCRUART_SS1_PIN)
    #include "SCRUART_spi_ss1.h"
#endif /* (SCRUART_SS1_PIN) */

#if (SCRUART_SS2_PIN)
    #include "SCRUART_spi_ss2.h"
#endif /* (SCRUART_SS2_PIN) */

#if (SCRUART_SS3_PIN)
    #include "SCRUART_spi_ss3.h"
#endif /* (SCRUART_SS3_PIN) */

#if (SCRUART_I2C_PINS)
    #include "SCRUART_scl.h"
    #include "SCRUART_sda.h"
#endif /* (SCRUART_I2C_PINS) */

#if (SCRUART_SPI_MASTER_PINS)
#if (SCRUART_SPI_MASTER_SCLK_PIN)
    #include "SCRUART_sclk_m.h"
#endif /* (SCRUART_SPI_MASTER_SCLK_PIN) */

#if (SCRUART_SPI_MASTER_MOSI_PIN)
    #include "SCRUART_mosi_m.h"
#endif /* (SCRUART_SPI_MASTER_MOSI_PIN) */

#if (SCRUART_SPI_MASTER_MISO_PIN)
    #include "SCRUART_miso_m.h"
#endif /*(SCRUART_SPI_MASTER_MISO_PIN) */
#endif /* (SCRUART_SPI_MASTER_PINS) */

#if (SCRUART_SPI_SLAVE_PINS)
    #include "SCRUART_sclk_s.h"
    #include "SCRUART_ss_s.h"

#if (SCRUART_SPI_SLAVE_MOSI_PIN)
    #include "SCRUART_mosi_s.h"
#endif /* (SCRUART_SPI_SLAVE_MOSI_PIN) */

#if (SCRUART_SPI_SLAVE_MISO_PIN)
    #include "SCRUART_miso_s.h"
#endif /*(SCRUART_SPI_SLAVE_MISO_PIN) */
#endif /* (SCRUART_SPI_SLAVE_PINS) */

#if (SCRUART_SPI_MASTER_SS0_PIN)
    #include "SCRUART_ss0_m.h"
#endif /* (SCRUART_SPI_MASTER_SS0_PIN) */

#if (SCRUART_SPI_MASTER_SS1_PIN)
    #include "SCRUART_ss1_m.h"
#endif /* (SCRUART_SPI_MASTER_SS1_PIN) */

#if (SCRUART_SPI_MASTER_SS2_PIN)
    #include "SCRUART_ss2_m.h"
#endif /* (SCRUART_SPI_MASTER_SS2_PIN) */

#if (SCRUART_SPI_MASTER_SS3_PIN)
    #include "SCRUART_ss3_m.h"
#endif /* (SCRUART_SPI_MASTER_SS3_PIN) */

#if (SCRUART_UART_TX_PIN)
    #include "SCRUART_tx.h"
#endif /* (SCRUART_UART_TX_PIN) */

#if (SCRUART_UART_RX_TX_PIN)
    #include "SCRUART_rx_tx.h"
#endif /* (SCRUART_UART_RX_TX_PIN) */

#if (SCRUART_UART_RX_PIN)
    #include "SCRUART_rx.h"
#endif /* (SCRUART_UART_RX_PIN) */

#if (SCRUART_UART_RX_WAKE_PIN)
    #include "SCRUART_rx_wake.h"
#endif /* (SCRUART_UART_RX_WAKE_PIN) */

#if (SCRUART_UART_RTS_PIN)
    #include "SCRUART_rts.h"
#endif /* (SCRUART_UART_RTS_PIN) */

#if (SCRUART_UART_CTS_PIN)
    #include "SCRUART_cts.h"
#endif /* (SCRUART_UART_CTS_PIN) */


/***************************************
*              Registers
***************************************/

#if (SCRUART_RX_SCL_MOSI_PIN)
    #define SCRUART_RX_SCL_MOSI_HSIOM_REG   (*(reg32 *) SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM)
    #define SCRUART_RX_SCL_MOSI_HSIOM_PTR   ( (reg32 *) SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM)
    
    #define SCRUART_RX_SCL_MOSI_HSIOM_MASK      (SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM_MASK)
    #define SCRUART_RX_SCL_MOSI_HSIOM_POS       (SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM_SHIFT)
    #define SCRUART_RX_SCL_MOSI_HSIOM_SEL_GPIO  (SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM_GPIO)
    #define SCRUART_RX_SCL_MOSI_HSIOM_SEL_I2C   (SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM_I2C)
    #define SCRUART_RX_SCL_MOSI_HSIOM_SEL_SPI   (SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM_SPI)
    #define SCRUART_RX_SCL_MOSI_HSIOM_SEL_UART  (SCRUART_uart_rx_i2c_scl_spi_mosi__0__HSIOM_UART)
    
#elif (SCRUART_RX_WAKE_SCL_MOSI_PIN)
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG   (*(reg32 *) SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM)
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_PTR   ( (reg32 *) SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM)
    
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_MASK      (SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_MASK)
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_POS       (SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_SHIFT)
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_SEL_GPIO  (SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_GPIO)
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_SEL_I2C   (SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_I2C)
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_SEL_SPI   (SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_SPI)
    #define SCRUART_RX_WAKE_SCL_MOSI_HSIOM_SEL_UART  (SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__HSIOM_UART)    
   
    #define SCRUART_RX_WAKE_SCL_MOSI_INTCFG_REG (*(reg32 *) SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__INTCFG)
    #define SCRUART_RX_WAKE_SCL_MOSI_INTCFG_PTR ( (reg32 *) SCRUART_uart_rx_wake_i2c_scl_spi_mosi__0__INTCFG)
    #define SCRUART_RX_WAKE_SCL_MOSI_INTCFG_TYPE_POS  (SCRUART_uart_rx_wake_i2c_scl_spi_mosi__SHIFT)
    #define SCRUART_RX_WAKE_SCL_MOSI_INTCFG_TYPE_MASK ((uint32) SCRUART_INTCFG_TYPE_MASK << \
                                                                           SCRUART_RX_WAKE_SCL_MOSI_INTCFG_TYPE_POS)
#else
    /* None of pins SCRUART_RX_SCL_MOSI_PIN or SCRUART_RX_WAKE_SCL_MOSI_PIN present.*/
#endif /* (SCRUART_RX_SCL_MOSI_PIN) */

#if (SCRUART_TX_SDA_MISO_PIN)
    #define SCRUART_TX_SDA_MISO_HSIOM_REG   (*(reg32 *) SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM)
    #define SCRUART_TX_SDA_MISO_HSIOM_PTR   ( (reg32 *) SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM)
    
    #define SCRUART_TX_SDA_MISO_HSIOM_MASK      (SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM_MASK)
    #define SCRUART_TX_SDA_MISO_HSIOM_POS       (SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM_SHIFT)
    #define SCRUART_TX_SDA_MISO_HSIOM_SEL_GPIO  (SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM_GPIO)
    #define SCRUART_TX_SDA_MISO_HSIOM_SEL_I2C   (SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM_I2C)
    #define SCRUART_TX_SDA_MISO_HSIOM_SEL_SPI   (SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM_SPI)
    #define SCRUART_TX_SDA_MISO_HSIOM_SEL_UART  (SCRUART_uart_tx_i2c_sda_spi_miso__0__HSIOM_UART)
#endif /* (SCRUART_TX_SDA_MISO_PIN) */

#if (SCRUART_CTS_SCLK_PIN)
    #define SCRUART_CTS_SCLK_HSIOM_REG   (*(reg32 *) SCRUART_uart_cts_spi_sclk__0__HSIOM)
    #define SCRUART_CTS_SCLK_HSIOM_PTR   ( (reg32 *) SCRUART_uart_cts_spi_sclk__0__HSIOM)
    
    #define SCRUART_CTS_SCLK_HSIOM_MASK      (SCRUART_uart_cts_spi_sclk__0__HSIOM_MASK)
    #define SCRUART_CTS_SCLK_HSIOM_POS       (SCRUART_uart_cts_spi_sclk__0__HSIOM_SHIFT)
    #define SCRUART_CTS_SCLK_HSIOM_SEL_GPIO  (SCRUART_uart_cts_spi_sclk__0__HSIOM_GPIO)
    #define SCRUART_CTS_SCLK_HSIOM_SEL_I2C   (SCRUART_uart_cts_spi_sclk__0__HSIOM_I2C)
    #define SCRUART_CTS_SCLK_HSIOM_SEL_SPI   (SCRUART_uart_cts_spi_sclk__0__HSIOM_SPI)
    #define SCRUART_CTS_SCLK_HSIOM_SEL_UART  (SCRUART_uart_cts_spi_sclk__0__HSIOM_UART)
#endif /* (SCRUART_CTS_SCLK_PIN) */

#if (SCRUART_RTS_SS0_PIN)
    #define SCRUART_RTS_SS0_HSIOM_REG   (*(reg32 *) SCRUART_uart_rts_spi_ss0__0__HSIOM)
    #define SCRUART_RTS_SS0_HSIOM_PTR   ( (reg32 *) SCRUART_uart_rts_spi_ss0__0__HSIOM)
    
    #define SCRUART_RTS_SS0_HSIOM_MASK      (SCRUART_uart_rts_spi_ss0__0__HSIOM_MASK)
    #define SCRUART_RTS_SS0_HSIOM_POS       (SCRUART_uart_rts_spi_ss0__0__HSIOM_SHIFT)
    #define SCRUART_RTS_SS0_HSIOM_SEL_GPIO  (SCRUART_uart_rts_spi_ss0__0__HSIOM_GPIO)
    #define SCRUART_RTS_SS0_HSIOM_SEL_I2C   (SCRUART_uart_rts_spi_ss0__0__HSIOM_I2C)
    #define SCRUART_RTS_SS0_HSIOM_SEL_SPI   (SCRUART_uart_rts_spi_ss0__0__HSIOM_SPI)
#if !(SCRUART_CY_SCBIP_V0 || SCRUART_CY_SCBIP_V1)
    #define SCRUART_RTS_SS0_HSIOM_SEL_UART  (SCRUART_uart_rts_spi_ss0__0__HSIOM_UART)
#endif /* !(SCRUART_CY_SCBIP_V0 || SCRUART_CY_SCBIP_V1) */
#endif /* (SCRUART_RTS_SS0_PIN) */

#if (SCRUART_SS1_PIN)
    #define SCRUART_SS1_HSIOM_REG  (*(reg32 *) SCRUART_spi_ss1__0__HSIOM)
    #define SCRUART_SS1_HSIOM_PTR  ( (reg32 *) SCRUART_spi_ss1__0__HSIOM)
    
    #define SCRUART_SS1_HSIOM_MASK     (SCRUART_spi_ss1__0__HSIOM_MASK)
    #define SCRUART_SS1_HSIOM_POS      (SCRUART_spi_ss1__0__HSIOM_SHIFT)
    #define SCRUART_SS1_HSIOM_SEL_GPIO (SCRUART_spi_ss1__0__HSIOM_GPIO)
    #define SCRUART_SS1_HSIOM_SEL_I2C  (SCRUART_spi_ss1__0__HSIOM_I2C)
    #define SCRUART_SS1_HSIOM_SEL_SPI  (SCRUART_spi_ss1__0__HSIOM_SPI)
#endif /* (SCRUART_SS1_PIN) */

#if (SCRUART_SS2_PIN)
    #define SCRUART_SS2_HSIOM_REG     (*(reg32 *) SCRUART_spi_ss2__0__HSIOM)
    #define SCRUART_SS2_HSIOM_PTR     ( (reg32 *) SCRUART_spi_ss2__0__HSIOM)
    
    #define SCRUART_SS2_HSIOM_MASK     (SCRUART_spi_ss2__0__HSIOM_MASK)
    #define SCRUART_SS2_HSIOM_POS      (SCRUART_spi_ss2__0__HSIOM_SHIFT)
    #define SCRUART_SS2_HSIOM_SEL_GPIO (SCRUART_spi_ss2__0__HSIOM_GPIO)
    #define SCRUART_SS2_HSIOM_SEL_I2C  (SCRUART_spi_ss2__0__HSIOM_I2C)
    #define SCRUART_SS2_HSIOM_SEL_SPI  (SCRUART_spi_ss2__0__HSIOM_SPI)
#endif /* (SCRUART_SS2_PIN) */

#if (SCRUART_SS3_PIN)
    #define SCRUART_SS3_HSIOM_REG     (*(reg32 *) SCRUART_spi_ss3__0__HSIOM)
    #define SCRUART_SS3_HSIOM_PTR     ( (reg32 *) SCRUART_spi_ss3__0__HSIOM)
    
    #define SCRUART_SS3_HSIOM_MASK     (SCRUART_spi_ss3__0__HSIOM_MASK)
    #define SCRUART_SS3_HSIOM_POS      (SCRUART_spi_ss3__0__HSIOM_SHIFT)
    #define SCRUART_SS3_HSIOM_SEL_GPIO (SCRUART_spi_ss3__0__HSIOM_GPIO)
    #define SCRUART_SS3_HSIOM_SEL_I2C  (SCRUART_spi_ss3__0__HSIOM_I2C)
    #define SCRUART_SS3_HSIOM_SEL_SPI  (SCRUART_spi_ss3__0__HSIOM_SPI)
#endif /* (SCRUART_SS3_PIN) */

#if (SCRUART_I2C_PINS)
    #define SCRUART_SCL_HSIOM_REG  (*(reg32 *) SCRUART_scl__0__HSIOM)
    #define SCRUART_SCL_HSIOM_PTR  ( (reg32 *) SCRUART_scl__0__HSIOM)
    
    #define SCRUART_SCL_HSIOM_MASK     (SCRUART_scl__0__HSIOM_MASK)
    #define SCRUART_SCL_HSIOM_POS      (SCRUART_scl__0__HSIOM_SHIFT)
    #define SCRUART_SCL_HSIOM_SEL_GPIO (SCRUART_sda__0__HSIOM_GPIO)
    #define SCRUART_SCL_HSIOM_SEL_I2C  (SCRUART_sda__0__HSIOM_I2C)
    
    #define SCRUART_SDA_HSIOM_REG  (*(reg32 *) SCRUART_sda__0__HSIOM)
    #define SCRUART_SDA_HSIOM_PTR  ( (reg32 *) SCRUART_sda__0__HSIOM)
    
    #define SCRUART_SDA_HSIOM_MASK     (SCRUART_sda__0__HSIOM_MASK)
    #define SCRUART_SDA_HSIOM_POS      (SCRUART_sda__0__HSIOM_SHIFT)
    #define SCRUART_SDA_HSIOM_SEL_GPIO (SCRUART_sda__0__HSIOM_GPIO)
    #define SCRUART_SDA_HSIOM_SEL_I2C  (SCRUART_sda__0__HSIOM_I2C)
#endif /* (SCRUART_I2C_PINS) */

#if (SCRUART_SPI_SLAVE_PINS)
    #define SCRUART_SCLK_S_HSIOM_REG   (*(reg32 *) SCRUART_sclk_s__0__HSIOM)
    #define SCRUART_SCLK_S_HSIOM_PTR   ( (reg32 *) SCRUART_sclk_s__0__HSIOM)
    
    #define SCRUART_SCLK_S_HSIOM_MASK      (SCRUART_sclk_s__0__HSIOM_MASK)
    #define SCRUART_SCLK_S_HSIOM_POS       (SCRUART_sclk_s__0__HSIOM_SHIFT)
    #define SCRUART_SCLK_S_HSIOM_SEL_GPIO  (SCRUART_sclk_s__0__HSIOM_GPIO)
    #define SCRUART_SCLK_S_HSIOM_SEL_SPI   (SCRUART_sclk_s__0__HSIOM_SPI)
    
    #define SCRUART_SS0_S_HSIOM_REG    (*(reg32 *) SCRUART_ss0_s__0__HSIOM)
    #define SCRUART_SS0_S_HSIOM_PTR    ( (reg32 *) SCRUART_ss0_s__0__HSIOM)
    
    #define SCRUART_SS0_S_HSIOM_MASK       (SCRUART_ss0_s__0__HSIOM_MASK)
    #define SCRUART_SS0_S_HSIOM_POS        (SCRUART_ss0_s__0__HSIOM_SHIFT)
    #define SCRUART_SS0_S_HSIOM_SEL_GPIO   (SCRUART_ss0_s__0__HSIOM_GPIO)  
    #define SCRUART_SS0_S_HSIOM_SEL_SPI    (SCRUART_ss0_s__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_SLAVE_PINS) */

#if (SCRUART_SPI_SLAVE_MOSI_PIN)
    #define SCRUART_MOSI_S_HSIOM_REG   (*(reg32 *) SCRUART_mosi_s__0__HSIOM)
    #define SCRUART_MOSI_S_HSIOM_PTR   ( (reg32 *) SCRUART_mosi_s__0__HSIOM)
    
    #define SCRUART_MOSI_S_HSIOM_MASK      (SCRUART_mosi_s__0__HSIOM_MASK)
    #define SCRUART_MOSI_S_HSIOM_POS       (SCRUART_mosi_s__0__HSIOM_SHIFT)
    #define SCRUART_MOSI_S_HSIOM_SEL_GPIO  (SCRUART_mosi_s__0__HSIOM_GPIO)
    #define SCRUART_MOSI_S_HSIOM_SEL_SPI   (SCRUART_mosi_s__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_SLAVE_MOSI_PIN) */

#if (SCRUART_SPI_SLAVE_MISO_PIN)
    #define SCRUART_MISO_S_HSIOM_REG   (*(reg32 *) SCRUART_miso_s__0__HSIOM)
    #define SCRUART_MISO_S_HSIOM_PTR   ( (reg32 *) SCRUART_miso_s__0__HSIOM)
    
    #define SCRUART_MISO_S_HSIOM_MASK      (SCRUART_miso_s__0__HSIOM_MASK)
    #define SCRUART_MISO_S_HSIOM_POS       (SCRUART_miso_s__0__HSIOM_SHIFT)
    #define SCRUART_MISO_S_HSIOM_SEL_GPIO  (SCRUART_miso_s__0__HSIOM_GPIO)
    #define SCRUART_MISO_S_HSIOM_SEL_SPI   (SCRUART_miso_s__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_SLAVE_MISO_PIN) */

#if (SCRUART_SPI_MASTER_MISO_PIN)
    #define SCRUART_MISO_M_HSIOM_REG   (*(reg32 *) SCRUART_miso_m__0__HSIOM)
    #define SCRUART_MISO_M_HSIOM_PTR   ( (reg32 *) SCRUART_miso_m__0__HSIOM)
    
    #define SCRUART_MISO_M_HSIOM_MASK      (SCRUART_miso_m__0__HSIOM_MASK)
    #define SCRUART_MISO_M_HSIOM_POS       (SCRUART_miso_m__0__HSIOM_SHIFT)
    #define SCRUART_MISO_M_HSIOM_SEL_GPIO  (SCRUART_miso_m__0__HSIOM_GPIO)
    #define SCRUART_MISO_M_HSIOM_SEL_SPI   (SCRUART_miso_m__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_MASTER_MISO_PIN) */

#if (SCRUART_SPI_MASTER_MOSI_PIN)
    #define SCRUART_MOSI_M_HSIOM_REG   (*(reg32 *) SCRUART_mosi_m__0__HSIOM)
    #define SCRUART_MOSI_M_HSIOM_PTR   ( (reg32 *) SCRUART_mosi_m__0__HSIOM)
    
    #define SCRUART_MOSI_M_HSIOM_MASK      (SCRUART_mosi_m__0__HSIOM_MASK)
    #define SCRUART_MOSI_M_HSIOM_POS       (SCRUART_mosi_m__0__HSIOM_SHIFT)
    #define SCRUART_MOSI_M_HSIOM_SEL_GPIO  (SCRUART_mosi_m__0__HSIOM_GPIO)
    #define SCRUART_MOSI_M_HSIOM_SEL_SPI   (SCRUART_mosi_m__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_MASTER_MOSI_PIN) */

#if (SCRUART_SPI_MASTER_SCLK_PIN)
    #define SCRUART_SCLK_M_HSIOM_REG   (*(reg32 *) SCRUART_sclk_m__0__HSIOM)
    #define SCRUART_SCLK_M_HSIOM_PTR   ( (reg32 *) SCRUART_sclk_m__0__HSIOM)
    
    #define SCRUART_SCLK_M_HSIOM_MASK      (SCRUART_sclk_m__0__HSIOM_MASK)
    #define SCRUART_SCLK_M_HSIOM_POS       (SCRUART_sclk_m__0__HSIOM_SHIFT)
    #define SCRUART_SCLK_M_HSIOM_SEL_GPIO  (SCRUART_sclk_m__0__HSIOM_GPIO)
    #define SCRUART_SCLK_M_HSIOM_SEL_SPI   (SCRUART_sclk_m__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_MASTER_SCLK_PIN) */

#if (SCRUART_SPI_MASTER_SS0_PIN)
    #define SCRUART_SS0_M_HSIOM_REG    (*(reg32 *) SCRUART_ss0_m__0__HSIOM)
    #define SCRUART_SS0_M_HSIOM_PTR    ( (reg32 *) SCRUART_ss0_m__0__HSIOM)
    
    #define SCRUART_SS0_M_HSIOM_MASK       (SCRUART_ss0_m__0__HSIOM_MASK)
    #define SCRUART_SS0_M_HSIOM_POS        (SCRUART_ss0_m__0__HSIOM_SHIFT)
    #define SCRUART_SS0_M_HSIOM_SEL_GPIO   (SCRUART_ss0_m__0__HSIOM_GPIO)
    #define SCRUART_SS0_M_HSIOM_SEL_SPI    (SCRUART_ss0_m__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_MASTER_SS0_PIN) */

#if (SCRUART_SPI_MASTER_SS1_PIN)
    #define SCRUART_SS1_M_HSIOM_REG    (*(reg32 *) SCRUART_ss1_m__0__HSIOM)
    #define SCRUART_SS1_M_HSIOM_PTR    ( (reg32 *) SCRUART_ss1_m__0__HSIOM)
    
    #define SCRUART_SS1_M_HSIOM_MASK       (SCRUART_ss1_m__0__HSIOM_MASK)
    #define SCRUART_SS1_M_HSIOM_POS        (SCRUART_ss1_m__0__HSIOM_SHIFT)
    #define SCRUART_SS1_M_HSIOM_SEL_GPIO   (SCRUART_ss1_m__0__HSIOM_GPIO)
    #define SCRUART_SS1_M_HSIOM_SEL_SPI    (SCRUART_ss1_m__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_MASTER_SS1_PIN) */

#if (SCRUART_SPI_MASTER_SS2_PIN)
    #define SCRUART_SS2_M_HSIOM_REG    (*(reg32 *) SCRUART_ss2_m__0__HSIOM)
    #define SCRUART_SS2_M_HSIOM_PTR    ( (reg32 *) SCRUART_ss2_m__0__HSIOM)
    
    #define SCRUART_SS2_M_HSIOM_MASK       (SCRUART_ss2_m__0__HSIOM_MASK)
    #define SCRUART_SS2_M_HSIOM_POS        (SCRUART_ss2_m__0__HSIOM_SHIFT)
    #define SCRUART_SS2_M_HSIOM_SEL_GPIO   (SCRUART_ss2_m__0__HSIOM_GPIO)
    #define SCRUART_SS2_M_HSIOM_SEL_SPI    (SCRUART_ss2_m__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_MASTER_SS2_PIN) */

#if (SCRUART_SPI_MASTER_SS3_PIN)
    #define SCRUART_SS3_M_HSIOM_REG    (*(reg32 *) SCRUART_ss3_m__0__HSIOM)
    #define SCRUART_SS3_M_HSIOM_PTR    ( (reg32 *) SCRUART_ss3_m__0__HSIOM)
    
    #define SCRUART_SS3_M_HSIOM_MASK      (SCRUART_ss3_m__0__HSIOM_MASK)
    #define SCRUART_SS3_M_HSIOM_POS       (SCRUART_ss3_m__0__HSIOM_SHIFT)
    #define SCRUART_SS3_M_HSIOM_SEL_GPIO  (SCRUART_ss3_m__0__HSIOM_GPIO)
    #define SCRUART_SS3_M_HSIOM_SEL_SPI   (SCRUART_ss3_m__0__HSIOM_SPI)
#endif /* (SCRUART_SPI_MASTER_SS3_PIN) */

#if (SCRUART_UART_RX_PIN)
    #define SCRUART_RX_HSIOM_REG   (*(reg32 *) SCRUART_rx__0__HSIOM)
    #define SCRUART_RX_HSIOM_PTR   ( (reg32 *) SCRUART_rx__0__HSIOM)
    
    #define SCRUART_RX_HSIOM_MASK      (SCRUART_rx__0__HSIOM_MASK)
    #define SCRUART_RX_HSIOM_POS       (SCRUART_rx__0__HSIOM_SHIFT)
    #define SCRUART_RX_HSIOM_SEL_GPIO  (SCRUART_rx__0__HSIOM_GPIO)
    #define SCRUART_RX_HSIOM_SEL_UART  (SCRUART_rx__0__HSIOM_UART)
#endif /* (SCRUART_UART_RX_PIN) */

#if (SCRUART_UART_RX_WAKE_PIN)
    #define SCRUART_RX_WAKE_HSIOM_REG   (*(reg32 *) SCRUART_rx_wake__0__HSIOM)
    #define SCRUART_RX_WAKE_HSIOM_PTR   ( (reg32 *) SCRUART_rx_wake__0__HSIOM)
    
    #define SCRUART_RX_WAKE_HSIOM_MASK      (SCRUART_rx_wake__0__HSIOM_MASK)
    #define SCRUART_RX_WAKE_HSIOM_POS       (SCRUART_rx_wake__0__HSIOM_SHIFT)
    #define SCRUART_RX_WAKE_HSIOM_SEL_GPIO  (SCRUART_rx_wake__0__HSIOM_GPIO)
    #define SCRUART_RX_WAKE_HSIOM_SEL_UART  (SCRUART_rx_wake__0__HSIOM_UART)
#endif /* (SCRUART_UART_WAKE_RX_PIN) */

#if (SCRUART_UART_CTS_PIN)
    #define SCRUART_CTS_HSIOM_REG   (*(reg32 *) SCRUART_cts__0__HSIOM)
    #define SCRUART_CTS_HSIOM_PTR   ( (reg32 *) SCRUART_cts__0__HSIOM)
    
    #define SCRUART_CTS_HSIOM_MASK      (SCRUART_cts__0__HSIOM_MASK)
    #define SCRUART_CTS_HSIOM_POS       (SCRUART_cts__0__HSIOM_SHIFT)
    #define SCRUART_CTS_HSIOM_SEL_GPIO  (SCRUART_cts__0__HSIOM_GPIO)
    #define SCRUART_CTS_HSIOM_SEL_UART  (SCRUART_cts__0__HSIOM_UART)
#endif /* (SCRUART_UART_CTS_PIN) */

#if (SCRUART_UART_TX_PIN)
    #define SCRUART_TX_HSIOM_REG   (*(reg32 *) SCRUART_tx__0__HSIOM)
    #define SCRUART_TX_HSIOM_PTR   ( (reg32 *) SCRUART_tx__0__HSIOM)
    
    #define SCRUART_TX_HSIOM_MASK      (SCRUART_tx__0__HSIOM_MASK)
    #define SCRUART_TX_HSIOM_POS       (SCRUART_tx__0__HSIOM_SHIFT)
    #define SCRUART_TX_HSIOM_SEL_GPIO  (SCRUART_tx__0__HSIOM_GPIO)
    #define SCRUART_TX_HSIOM_SEL_UART  (SCRUART_tx__0__HSIOM_UART)
#endif /* (SCRUART_UART_TX_PIN) */

#if (SCRUART_UART_RX_TX_PIN)
    #define SCRUART_RX_TX_HSIOM_REG   (*(reg32 *) SCRUART_rx_tx__0__HSIOM)
    #define SCRUART_RX_TX_HSIOM_PTR   ( (reg32 *) SCRUART_rx_tx__0__HSIOM)
    
    #define SCRUART_RX_TX_HSIOM_MASK      (SCRUART_rx_tx__0__HSIOM_MASK)
    #define SCRUART_RX_TX_HSIOM_POS       (SCRUART_rx_tx__0__HSIOM_SHIFT)
    #define SCRUART_RX_TX_HSIOM_SEL_GPIO  (SCRUART_rx_tx__0__HSIOM_GPIO)
    #define SCRUART_RX_TX_HSIOM_SEL_UART  (SCRUART_rx_tx__0__HSIOM_UART)
#endif /* (SCRUART_UART_RX_TX_PIN) */

#if (SCRUART_UART_RTS_PIN)
    #define SCRUART_RTS_HSIOM_REG      (*(reg32 *) SCRUART_rts__0__HSIOM)
    #define SCRUART_RTS_HSIOM_PTR      ( (reg32 *) SCRUART_rts__0__HSIOM)
    
    #define SCRUART_RTS_HSIOM_MASK     (SCRUART_rts__0__HSIOM_MASK)
    #define SCRUART_RTS_HSIOM_POS      (SCRUART_rts__0__HSIOM_SHIFT)    
    #define SCRUART_RTS_HSIOM_SEL_GPIO (SCRUART_rts__0__HSIOM_GPIO)
    #define SCRUART_RTS_HSIOM_SEL_UART (SCRUART_rts__0__HSIOM_UART)    
#endif /* (SCRUART_UART_RTS_PIN) */


/***************************************
*        Registers Constants
***************************************/

/* HSIOM switch values. */ 
#define SCRUART_HSIOM_DEF_SEL      (0x00u)
#define SCRUART_HSIOM_GPIO_SEL     (0x00u)
/* The HSIOM values provided below are valid only for SCRUART_CY_SCBIP_V0 
* and SCRUART_CY_SCBIP_V1. It is not recommended to use them for 
* SCRUART_CY_SCBIP_V2. Use pin name specific HSIOM constants provided 
* above instead for any SCB IP block version.
*/
#define SCRUART_HSIOM_UART_SEL     (0x09u)
#define SCRUART_HSIOM_I2C_SEL      (0x0Eu)
#define SCRUART_HSIOM_SPI_SEL      (0x0Fu)

/* Pins settings index. */
#define SCRUART_RX_WAKE_SCL_MOSI_PIN_INDEX   (0u)
#define SCRUART_RX_SCL_MOSI_PIN_INDEX       (0u)
#define SCRUART_TX_SDA_MISO_PIN_INDEX       (1u)
#define SCRUART_CTS_SCLK_PIN_INDEX       (2u)
#define SCRUART_RTS_SS0_PIN_INDEX       (3u)
#define SCRUART_SS1_PIN_INDEX                  (4u)
#define SCRUART_SS2_PIN_INDEX                  (5u)
#define SCRUART_SS3_PIN_INDEX                  (6u)

/* Pins settings mask. */
#define SCRUART_RX_WAKE_SCL_MOSI_PIN_MASK ((uint32) 0x01u << SCRUART_RX_WAKE_SCL_MOSI_PIN_INDEX)
#define SCRUART_RX_SCL_MOSI_PIN_MASK     ((uint32) 0x01u << SCRUART_RX_SCL_MOSI_PIN_INDEX)
#define SCRUART_TX_SDA_MISO_PIN_MASK     ((uint32) 0x01u << SCRUART_TX_SDA_MISO_PIN_INDEX)
#define SCRUART_CTS_SCLK_PIN_MASK     ((uint32) 0x01u << SCRUART_CTS_SCLK_PIN_INDEX)
#define SCRUART_RTS_SS0_PIN_MASK     ((uint32) 0x01u << SCRUART_RTS_SS0_PIN_INDEX)
#define SCRUART_SS1_PIN_MASK                ((uint32) 0x01u << SCRUART_SS1_PIN_INDEX)
#define SCRUART_SS2_PIN_MASK                ((uint32) 0x01u << SCRUART_SS2_PIN_INDEX)
#define SCRUART_SS3_PIN_MASK                ((uint32) 0x01u << SCRUART_SS3_PIN_INDEX)

/* Pin interrupt constants. */
#define SCRUART_INTCFG_TYPE_MASK           (0x03u)
#define SCRUART_INTCFG_TYPE_FALLING_EDGE   (0x02u)

/* Pin Drive Mode constants. */
#define SCRUART_PIN_DM_ALG_HIZ  (0u)
#define SCRUART_PIN_DM_DIG_HIZ  (1u)
#define SCRUART_PIN_DM_OD_LO    (4u)
#define SCRUART_PIN_DM_STRONG   (6u)


/***************************************
*          Macro Definitions
***************************************/

/* Return drive mode of the pin */
#define SCRUART_DM_MASK    (0x7u)
#define SCRUART_DM_SIZE    (3u)
#define SCRUART_GET_P4_PIN_DM(reg, pos) \
    ( ((reg) & (uint32) ((uint32) SCRUART_DM_MASK << (SCRUART_DM_SIZE * (pos)))) >> \
                                                              (SCRUART_DM_SIZE * (pos)) )

#if (SCRUART_TX_SDA_MISO_PIN)
    #define SCRUART_CHECK_TX_SDA_MISO_PIN_USED \
                (SCRUART_PIN_DM_ALG_HIZ != \
                    SCRUART_GET_P4_PIN_DM(SCRUART_uart_tx_i2c_sda_spi_miso_PC, \
                                                   SCRUART_uart_tx_i2c_sda_spi_miso_SHIFT))
#endif /* (SCRUART_TX_SDA_MISO_PIN) */

#if (SCRUART_RTS_SS0_PIN)
    #define SCRUART_CHECK_RTS_SS0_PIN_USED \
                (SCRUART_PIN_DM_ALG_HIZ != \
                    SCRUART_GET_P4_PIN_DM(SCRUART_uart_rts_spi_ss0_PC, \
                                                   SCRUART_uart_rts_spi_ss0_SHIFT))
#endif /* (SCRUART_RTS_SS0_PIN) */

/* Set bits-mask in register */
#define SCRUART_SET_REGISTER_BITS(reg, mask, pos, mode) \
                    do                                           \
                    {                                            \
                        (reg) = (((reg) & ((uint32) ~(uint32) (mask))) | ((uint32) ((uint32) (mode) << (pos)))); \
                    }while(0)

/* Set bit in the register */
#define SCRUART_SET_REGISTER_BIT(reg, mask, val) \
                    ((val) ? ((reg) |= (mask)) : ((reg) &= ((uint32) ~((uint32) (mask)))))

#define SCRUART_SET_HSIOM_SEL(reg, mask, pos, sel) SCRUART_SET_REGISTER_BITS(reg, mask, pos, sel)
#define SCRUART_SET_INCFG_TYPE(reg, mask, pos, intType) \
                                                        SCRUART_SET_REGISTER_BITS(reg, mask, pos, intType)
#define SCRUART_SET_INP_DIS(reg, mask, val) SCRUART_SET_REGISTER_BIT(reg, mask, val)

/* SCRUART_SET_I2C_SCL_DR(val) - Sets I2C SCL DR register.
*  SCRUART_SET_I2C_SCL_HSIOM_SEL(sel) - Sets I2C SCL HSIOM settings.
*/
/* SCB I2C: scl signal */
#if (SCRUART_CY_SCBIP_V0)
#if (SCRUART_I2C_PINS)
    #define SCRUART_SET_I2C_SCL_DR(val) SCRUART_scl_Write(val)

    #define SCRUART_SET_I2C_SCL_HSIOM_SEL(sel) \
                          SCRUART_SET_HSIOM_SEL(SCRUART_SCL_HSIOM_REG,  \
                                                         SCRUART_SCL_HSIOM_MASK, \
                                                         SCRUART_SCL_HSIOM_POS,  \
                                                         (sel))
    #define SCRUART_WAIT_SCL_SET_HIGH  (0u == SCRUART_scl_Read())

/* Unconfigured SCB: scl signal */
#elif (SCRUART_RX_WAKE_SCL_MOSI_PIN)
    #define SCRUART_SET_I2C_SCL_DR(val) \
                            SCRUART_uart_rx_wake_i2c_scl_spi_mosi_Write(val)

    #define SCRUART_SET_I2C_SCL_HSIOM_SEL(sel) \
                    SCRUART_SET_HSIOM_SEL(SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG,  \
                                                   SCRUART_RX_WAKE_SCL_MOSI_HSIOM_MASK, \
                                                   SCRUART_RX_WAKE_SCL_MOSI_HSIOM_POS,  \
                                                   (sel))

    #define SCRUART_WAIT_SCL_SET_HIGH  (0u == SCRUART_uart_rx_wake_i2c_scl_spi_mosi_Read())

#elif (SCRUART_RX_SCL_MOSI_PIN)
    #define SCRUART_SET_I2C_SCL_DR(val) \
                            SCRUART_uart_rx_i2c_scl_spi_mosi_Write(val)


    #define SCRUART_SET_I2C_SCL_HSIOM_SEL(sel) \
                            SCRUART_SET_HSIOM_SEL(SCRUART_RX_SCL_MOSI_HSIOM_REG,  \
                                                           SCRUART_RX_SCL_MOSI_HSIOM_MASK, \
                                                           SCRUART_RX_SCL_MOSI_HSIOM_POS,  \
                                                           (sel))

    #define SCRUART_WAIT_SCL_SET_HIGH  (0u == SCRUART_uart_rx_i2c_scl_spi_mosi_Read())

#else
    #define SCRUART_SET_I2C_SCL_DR(val)        do{ /* Does nothing */ }while(0)
    #define SCRUART_SET_I2C_SCL_HSIOM_SEL(sel) do{ /* Does nothing */ }while(0)

    #define SCRUART_WAIT_SCL_SET_HIGH  (0u)
#endif /* (SCRUART_I2C_PINS) */

/* SCB I2C: sda signal */
#if (SCRUART_I2C_PINS)
    #define SCRUART_WAIT_SDA_SET_HIGH  (0u == SCRUART_sda_Read())
/* Unconfigured SCB: sda signal */
#elif (SCRUART_TX_SDA_MISO_PIN)
    #define SCRUART_WAIT_SDA_SET_HIGH  (0u == SCRUART_uart_tx_i2c_sda_spi_miso_Read())
#else
    #define SCRUART_WAIT_SDA_SET_HIGH  (0u)
#endif /* (SCRUART_MOSI_SCL_RX_PIN) */
#endif /* (SCRUART_CY_SCBIP_V0) */

/* Clear UART wakeup source */
#if (SCRUART_RX_SCL_MOSI_PIN)
    #define SCRUART_CLEAR_UART_RX_WAKE_INTR        do{ /* Does nothing */ }while(0)
    
#elif (SCRUART_RX_WAKE_SCL_MOSI_PIN)
    #define SCRUART_CLEAR_UART_RX_WAKE_INTR \
            do{                                      \
                (void) SCRUART_uart_rx_wake_i2c_scl_spi_mosi_ClearInterrupt(); \
            }while(0)

#elif(SCRUART_UART_RX_WAKE_PIN)
    #define SCRUART_CLEAR_UART_RX_WAKE_INTR \
            do{                                      \
                (void) SCRUART_rx_wake_ClearInterrupt(); \
            }while(0)
#else
#endif /* (SCRUART_RX_SCL_MOSI_PIN) */


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Unconfigured pins */
#define SCRUART_REMOVE_MOSI_SCL_RX_WAKE_PIN    SCRUART_REMOVE_RX_WAKE_SCL_MOSI_PIN
#define SCRUART_REMOVE_MOSI_SCL_RX_PIN         SCRUART_REMOVE_RX_SCL_MOSI_PIN
#define SCRUART_REMOVE_MISO_SDA_TX_PIN         SCRUART_REMOVE_TX_SDA_MISO_PIN
#ifndef SCRUART_REMOVE_SCLK_PIN
#define SCRUART_REMOVE_SCLK_PIN                SCRUART_REMOVE_CTS_SCLK_PIN
#endif /* SCRUART_REMOVE_SCLK_PIN */
#ifndef SCRUART_REMOVE_SS0_PIN
#define SCRUART_REMOVE_SS0_PIN                 SCRUART_REMOVE_RTS_SS0_PIN
#endif /* SCRUART_REMOVE_SS0_PIN */

/* Unconfigured pins */
#define SCRUART_MOSI_SCL_RX_WAKE_PIN   SCRUART_RX_WAKE_SCL_MOSI_PIN
#define SCRUART_MOSI_SCL_RX_PIN        SCRUART_RX_SCL_MOSI_PIN
#define SCRUART_MISO_SDA_TX_PIN        SCRUART_TX_SDA_MISO_PIN
#ifndef SCRUART_SCLK_PIN
#define SCRUART_SCLK_PIN               SCRUART_CTS_SCLK_PIN
#endif /* SCRUART_SCLK_PIN */
#ifndef SCRUART_SS0_PIN
#define SCRUART_SS0_PIN                SCRUART_RTS_SS0_PIN
#endif /* SCRUART_SS0_PIN */

#if (SCRUART_MOSI_SCL_RX_WAKE_PIN)
    #define SCRUART_MOSI_SCL_RX_WAKE_HSIOM_REG     SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define SCRUART_MOSI_SCL_RX_WAKE_HSIOM_PTR     SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define SCRUART_MOSI_SCL_RX_WAKE_HSIOM_MASK    SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define SCRUART_MOSI_SCL_RX_WAKE_HSIOM_POS     SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG

    #define SCRUART_MOSI_SCL_RX_WAKE_INTCFG_REG    SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define SCRUART_MOSI_SCL_RX_WAKE_INTCFG_PTR    SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG

    #define SCRUART_MOSI_SCL_RX_WAKE_INTCFG_TYPE_POS   SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG
    #define SCRUART_MOSI_SCL_RX_WAKE_INTCFG_TYPE_MASK  SCRUART_RX_WAKE_SCL_MOSI_HSIOM_REG
#endif /* (SCRUART_RX_WAKE_SCL_MOSI_PIN) */

#if (SCRUART_MOSI_SCL_RX_PIN)
    #define SCRUART_MOSI_SCL_RX_HSIOM_REG      SCRUART_RX_SCL_MOSI_HSIOM_REG
    #define SCRUART_MOSI_SCL_RX_HSIOM_PTR      SCRUART_RX_SCL_MOSI_HSIOM_PTR
    #define SCRUART_MOSI_SCL_RX_HSIOM_MASK     SCRUART_RX_SCL_MOSI_HSIOM_MASK
    #define SCRUART_MOSI_SCL_RX_HSIOM_POS      SCRUART_RX_SCL_MOSI_HSIOM_POS
#endif /* (SCRUART_MOSI_SCL_RX_PIN) */

#if (SCRUART_MISO_SDA_TX_PIN)
    #define SCRUART_MISO_SDA_TX_HSIOM_REG      SCRUART_TX_SDA_MISO_HSIOM_REG
    #define SCRUART_MISO_SDA_TX_HSIOM_PTR      SCRUART_TX_SDA_MISO_HSIOM_REG
    #define SCRUART_MISO_SDA_TX_HSIOM_MASK     SCRUART_TX_SDA_MISO_HSIOM_REG
    #define SCRUART_MISO_SDA_TX_HSIOM_POS      SCRUART_TX_SDA_MISO_HSIOM_REG
#endif /* (SCRUART_MISO_SDA_TX_PIN_PIN) */

#if (SCRUART_SCLK_PIN)
    #ifndef SCRUART_SCLK_HSIOM_REG
    #define SCRUART_SCLK_HSIOM_REG     SCRUART_CTS_SCLK_HSIOM_REG
    #define SCRUART_SCLK_HSIOM_PTR     SCRUART_CTS_SCLK_HSIOM_PTR
    #define SCRUART_SCLK_HSIOM_MASK    SCRUART_CTS_SCLK_HSIOM_MASK
    #define SCRUART_SCLK_HSIOM_POS     SCRUART_CTS_SCLK_HSIOM_POS
    #endif /* SCRUART_SCLK_HSIOM_REG */
#endif /* (SCRUART_SCLK_PIN) */

#if (SCRUART_SS0_PIN)
    #ifndef SCRUART_SS0_HSIOM_REG
    #define SCRUART_SS0_HSIOM_REG      SCRUART_RTS_SS0_HSIOM_REG
    #define SCRUART_SS0_HSIOM_PTR      SCRUART_RTS_SS0_HSIOM_PTR
    #define SCRUART_SS0_HSIOM_MASK     SCRUART_RTS_SS0_HSIOM_MASK
    #define SCRUART_SS0_HSIOM_POS      SCRUART_RTS_SS0_HSIOM_POS
    #endif /* SCRUART_SS0_HSIOM_REG */
#endif /* (SCRUART_SS0_PIN) */

#define SCRUART_MOSI_SCL_RX_WAKE_PIN_INDEX SCRUART_RX_WAKE_SCL_MOSI_PIN_INDEX
#define SCRUART_MOSI_SCL_RX_PIN_INDEX      SCRUART_RX_SCL_MOSI_PIN_INDEX
#define SCRUART_MISO_SDA_TX_PIN_INDEX      SCRUART_TX_SDA_MISO_PIN_INDEX
#ifndef SCRUART_SCLK_PIN_INDEX
#define SCRUART_SCLK_PIN_INDEX             SCRUART_CTS_SCLK_PIN_INDEX
#endif /* SCRUART_SCLK_PIN_INDEX */
#ifndef SCRUART_SS0_PIN_INDEX
#define SCRUART_SS0_PIN_INDEX              SCRUART_RTS_SS0_PIN_INDEX
#endif /* SCRUART_SS0_PIN_INDEX */

#define SCRUART_MOSI_SCL_RX_WAKE_PIN_MASK SCRUART_RX_WAKE_SCL_MOSI_PIN_MASK
#define SCRUART_MOSI_SCL_RX_PIN_MASK      SCRUART_RX_SCL_MOSI_PIN_MASK
#define SCRUART_MISO_SDA_TX_PIN_MASK      SCRUART_TX_SDA_MISO_PIN_MASK
#ifndef SCRUART_SCLK_PIN_MASK
#define SCRUART_SCLK_PIN_MASK             SCRUART_CTS_SCLK_PIN_MASK
#endif /* SCRUART_SCLK_PIN_MASK */
#ifndef SCRUART_SS0_PIN_MASK
#define SCRUART_SS0_PIN_MASK              SCRUART_RTS_SS0_PIN_MASK
#endif /* SCRUART_SS0_PIN_MASK */

#endif /* (CY_SCB_PINS_SCRUART_H) */


/* [] END OF FILE */
